<?php
$connection=mysqli_connect("localhost","root","welcome123","hospital");
?>
