<?php
include 'connection.php';
if($connection)
{
echo "connection estalablished";
}
else
{
echo "error";
}
$name=$_POST['username'];
$mailid=$_POST['mail'];
$tel=$_POST['tel'];
$query="CREATE TABLE DETAIL(name VARCHAR(15),mailid VARCHAR(30),tel VARCHAR(10));";
if(mysqli_query($connection,$query))
{
	echo "table created";
}
else
{
echo "error:".mysqli_error($connection);
}
$query="INSERT INTO DETAIL VALUES('$name','$mailid','$tel');";
if(mysqli_query($connection,$query))
{
	echo "value inserted";
}
else
{
echo "error:".mysqli_error($connection);
}
$query="SLECT *FROM DETAIL;";
$check=mysqli_query($connection,$query);
if(mysqli_num_rows($check))
{
	while($row=mysqli_fetch_array($check))
	echo $row['name']." ".$row['mailid']." ".$row['tel']."<br>";
}
?>
