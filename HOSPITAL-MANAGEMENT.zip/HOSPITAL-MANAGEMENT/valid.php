<!DOCTYPE html>
<html>
<body>
<center>
<h1><u>Book Your Appiontment</u></h1>
<form action="valid.php" method="POST">
	<label for="text">PATIENT NAME :</label>
	<input type="text" name="username" placeholder="ENTER YOUR NAME" id="text"></br></br>
    <label for="email"> PATIENT EMAIL :</label>
    <input type="email" name="mail" placeholder=" ENTER YOUR EMAIL" id="email"></br></br>
    <label for="tele" >PATIENT MOBILE NUMBER :</label>
    <input type="tel" min="0" max="10" id="tele" name="tel" placeholder=" ENTER YOUR MOBILE"></br></br>
    <label for="gen">GENDER :</label>
    <input type="radio" name="gender" value="Male" id="gen">Male
    <input type="radio" name="gender" value="Female" id="gen">Female</br></br>
    <label for="age">ENTER YOUR AGE :</label>
    <input type="number" name="number" id="age"></br></br>
    <label for="select">SELECT : </label>
    <select name="dropdown" id="select">
    <option selected>SELECT ONE TIME SLOT</option>
     <option value="09:30 TO 10:30" name="dropdown">09:30 to 10:30</option>
     <option value="11:00 TO 12:30" name="dropdown">11:00 to 12:30</option>
      <option value="02:00 TO 03:30" name="dropdown">02:00 to 03:30</option>
 <option value="04:00 TO 05:30" name="dropdown">04:00 to 05:30</option>
 <option value="06:30 TO 07:30" name="dropdown">06:30 to 07:30</option>
</select></br></br>
    <label for=text">ASK ANY QUERIES:</label><br><br>
    <textarea rows=10 cols=50 name="comment" style="font-size:15px" name="comments" id="text"></textarea></br></br>
    <button type="submit">BOOK APPIONTMENT</button>
    </form>
</br>
 


</center>
<?php
$name=$_POST["username"];
echo $name."<br>";
$mail=$_POST["mail"];
echo $mail."<br>";
$num=$_POST["tel"];
echo $num."<br>";
$gender=$_POST["gender"];
echo "$gender"."<br>";
$number=$_POST["number"];
echo "$number"."<br>";
$dropdown=$_POST["dropdown"];
echo "$dropdown"."<br>";
$message=$_POST["comments"];
echo "$message"."<br>";
$doc="appointment.txt";
$a=fopen($doc,"w");
fwrite($a,$name);
fwrite($a,$mail);
fwrite($a,$num);
fwrite($a,$gender);
fwrite($a,$number);
fwrite($a,$dropdown);
fwrite($a,$message);
fclose($a);
?>
<a href="download.php">DOWNLOAD</a>

</body>
</html>
