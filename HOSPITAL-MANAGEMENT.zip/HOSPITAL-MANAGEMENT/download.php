<?php 

$file_url ="appointment.txt";
    header('Content-Disposition: attachment; filename=" '.basename($file_url)) . ' " ';
    readfile($file_url);
 
?>
