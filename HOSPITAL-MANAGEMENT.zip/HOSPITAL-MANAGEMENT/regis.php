<?php 

$file = "appointment.txt";
    header('Content-Disposition: attachment; filename=" '.basename($file)) . ' " ';
    readfile($file);
 
?>
